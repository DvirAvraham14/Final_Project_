#pragma once
#include"StaticObject.h"
class Obstacles :public StaticObject
{
public:
	using StaticObject::StaticObject;
	//	StaticObject()=default;
	//virtual void draw(sf::RenderWindow& target) const;

protected:

private:

};