#pragma once
#include"Obstacles.h"
class Spikes :public Obstacles
{
public:
	using Obstacles::Obstacles;

protected:

private:

};