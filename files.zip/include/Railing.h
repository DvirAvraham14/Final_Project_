#pragma once
#include"Obstacles.h"
class Railing :public Obstacles
{
public:
	using Obstacles::Obstacles;

protected:

private:

};