#include"Obstacles.h"



//void Obstacles::draw(sf::RenderWindow& target) const {
//	target.draw(m_sprite);
//}