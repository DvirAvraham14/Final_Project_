#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <SFML\Graphics.hpp>
#include "Controller.h"

int main()
{
	Controller game;
	game.run();

	return EXIT_SUCCESS;
}

