#include"GameObject.h"

GameObject::GameObject(const sf::Texture &texture, std::shared_ptr<b2World> world,sf::Vector2f pos)
	:m_world(world) 
{
	m_sprite.setTexture(texture);
	m_sprite.setOrigin(m_sprite.getGlobalBounds().width / 2,
					   m_sprite.getGlobalBounds().height / 2);
	m_contacting = false;
	CreateBody(pos);
}

GameObject::GameObject(std::shared_ptr<b2World> world)
	:m_world(world), m_body(nullptr)
{
	m_contacting = false;
}
	
void GameObject::CreateBody(sf::Vector2f pos) {
	b2BodyDef m_bodyDef;
	m_bodyDef.type = b2_dynamicBody;
	m_bodyDef.position.Set(pos.x , pos.y );
	m_body = m_world->CreateBody(&m_bodyDef);
	
	b2PolygonShape dynamicBox;
	dynamicBox.SetAsBox(m_sprite.getTexture()->getSize().x/2, 
		m_sprite.getTexture()->getSize().y / 2);
	b2FixtureDef fixtureDef;

	fixtureDef.shape = &dynamicBox;
	fixtureDef.density		=	 0.5f;
	fixtureDef.friction		=	 0.1f;
	m_body->CreateFixture(&fixtureDef);

	//b2MassData massa;
	//massa.mass = 0.0001f;
	//massa.center = m_body->GetLocalCenter();
	//m_body->SetMassData(&massa);

	m_body->SetUserData(this);
}

void GameObject::setMassa(float weight, b2Vec2 pos) {
	b2MassData massa;
	massa.mass = weight;
	massa.center = pos;
	m_body->SetMassData(&massa);
}

